package de.jowisoftware.luja.test;

public class FailMain {
    public static void main(final String[] args) {
        final StringBuilder builder = new StringBuilder();

        for(final String arg: args) {
            builder.append(arg);
        }

        throw new RuntimeException("successfull: " + builder.toString());
    }
}
